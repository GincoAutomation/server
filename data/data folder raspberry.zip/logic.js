module.exports = function(event, state) {
  if (event.type == 'uiInput') {
    //   if ((event.id.includes('lamp'), 0))
    //     return [
    //       {
    //         device: 'light_out0'.concat(even.id.charAt(event.id.lenght - 1)),
    //         data: { checked: !state['living.mainLight'].checked }
    //       }
    //     ];
  }
};
